import time

print("Agent starting...")
time.sleep(1)
print("Agent finished.")
