import time

print("Agent starting...")
time.sleep(2)
print("Agent finished.")
print("Hello there!")
