import time
print('Sleeper agent started...')
while True:
    time.sleep(1)